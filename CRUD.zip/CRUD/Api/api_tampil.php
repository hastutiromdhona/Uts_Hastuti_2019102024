<?php 
 $connect = new mysqli("localhost","root","","dbkaryawan");
 if ($connect){
	echo"connection Success";
} else {
	echo "connection Failed";
	exit();
}