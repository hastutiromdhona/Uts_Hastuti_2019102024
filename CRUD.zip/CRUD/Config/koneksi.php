<?php 
 $connect = new mysqli("localhost","root","","dbkaryawan");
 $data       = mysqli_query($connect, "select * from idemployers");
 $data       = mysqli_fetch_all($data, MYSQLI_ASSOC);

 echo json_encode($data);