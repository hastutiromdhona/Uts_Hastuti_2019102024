package com.example.uts_hastuti_2019102024

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
